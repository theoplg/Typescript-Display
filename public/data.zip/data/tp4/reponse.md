Il y a 4 message :
2 qui s'affichent sur le terminal d'astro car message lié au server (dans pages)
2 qui s'affichent sur la console du navigateur, dans client (scripts)
