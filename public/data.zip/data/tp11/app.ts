//Supposons que nous voulons créer une classe GenericStorage
//qui peut stocker des éléments de n'importe quel type :

class GenericStorage<T> {
  // <T> signife que la classe va manipuler des élemts de type qlc
  private data: Map<string, T> = new Map(); // la class contient un attribue data qui est une map avec des clé de type string et des valeurs  type T

  set(key: string, value: T): void {
    // on ajoute une paire clé/valeur
    this.data.set(key, value);
  }

  get(key: string): T | undefined {
    // ici get récupère la valeur associé à la clé key, le type retourné et soit T (ce que l'on a dit dans la class) soit undefined si la clé n'est associé à rien
    return this.data.get(key);
  }

  size(): number {
    // retourne le nombre d'elmt de la map
    return this.data.size;
  }
}
// Utilisation de la classe GenericStorage avec des nombres
let numberStorage = new GenericStorage<number>(); // ici T est donc un nombre
numberStorage.set("one", 1);
numberStorage.set("two", 2);
console.log(numberStorage.get("one")); // Affiche 1

// Utilisation de la classe GenericStorage avec des chaînes de caractères
let stringStorage = new GenericStorage<string>(); // ici c'est une chaine de carac
stringStorage.set("hello", "world");
stringStorage.set("goodbye", "cruel world");
console.log(stringStorage.get("hello")); // Affiche "world"

class Queue<T> {
  // TODO: Implementez les methodes ici
  private elements: T[] = []; // tableau d'éléments de type T

  enqueue(element: T): void {
    this.elements.push(element); // on ajoute un élement à la fin du tableau
  }

  dequeue(): T | undefined {
    if (this.size() === 0) {
      return undefined; // si la taille de la queue est 0 on retourne undefined
    }
    return this.elements.shift(); // on supprime le premier élement du tableau et le retourne
  }

  size(): number {
    return this.elements.length; // retourne la taille du tableau
  }
}

// Testez votre code ici
let numberQueue = new Queue<number>();
numberQueue.enqueue(1);
numberQueue.enqueue(2);
numberQueue.enqueue(3);
numberQueue.enqueue(4);
numberQueue.enqueue(5);
console.log(numberQueue.size());
console.log(numberQueue);
numberQueue.dequeue();
numberQueue.dequeue();
console.log(numberQueue.size());

let stringQueue = new Queue<string>();
stringQueue.enqueue("Salut");
stringQueue.enqueue("le ");
stringQueue.enqueue("TP");
stringQueue.enqueue("11");
console.log(stringQueue.size());
console.log(stringQueue);
stringQueue.dequeue();
stringQueue.dequeue();
console.log(stringQueue.size());
console.log(stringQueue);
