const message1: string = "Hello World";
console.log(message1);
