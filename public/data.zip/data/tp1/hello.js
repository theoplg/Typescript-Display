var message1 = "Hello World";
console.log(message1);
