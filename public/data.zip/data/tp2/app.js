var my_hello_message = "Hello, hello TYPESCRIPT World!";
// create a new heading 1 element
var my_title = document.createElement("h1");
my_title.textContent = my_hello_message;
// add the heading the document
document.body.appendChild(my_title);
