export function calculerJoursRestants(a: number){
    return 21-a;
}