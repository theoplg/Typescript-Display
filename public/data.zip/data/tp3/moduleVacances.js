"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.calculerJoursRestants = calculerJoursRestants;
function calculerJoursRestants(a) {
    return 21 - a;
}
